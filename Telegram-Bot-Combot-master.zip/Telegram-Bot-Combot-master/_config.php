<?php

return  array(
#######Telegram-Bot#####
'bot_token' => "bot token",//bot tokeni kiritilsin
'bot_user' => "bot username",//bot usernamesi kiritilsin
#######Administrator#####
'admin_id' => "admin id",//adminstrator idraqami
'admin_name' => "admin full name",// adminstrator ismi
);

?>